<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>Untitled Document</title>
</head>

<body>
<p>
  <?php

  ini_set("max_execution_time", 300000000000);
  $n=0;
$k = 0;
$t=0;
$c=0;
$p=0.0;
$d1='';
$con=mysql_connect('localhost','root','asd123456');
if(!$con){
echo "Connection Error";
exit();
}
$db=mysql_select_db('mypro',$con);

mysql_query("set character_set_server='utf8'");
mysql_query("set names 'utf8'");


$sql1=mysql_query("select word from fmalaycands",$con);
if($sql1){
while($row1=mysql_fetch_array($sql1)){
$d1=$row1[word];
echo "The Candidate Word is: ".$d1;

	$sql=mysql_query("select mcomm from malaycomm where mcomm like '% ".$d1." %'",$con);
		if($sql){
				while($row=mysql_fetch_array($sql)){
					$d=$row[mcomm];
					$c=$c+1;
				//	echo $d."<br>";
				//	echo "======================== <br>";
					$v_array = explode(" ", $d);
					$l = count($v_array);
					for ($x = 0; $x <= $l ; $x++) {

						$result = mysql_query("select * from malayseed where word ='".$v_array[$x]."'",$con);
							if (!$result) {
								exit;
							}
							else {
								$row5 = mysql_fetch_row($result);
								$d5=$row5[1];
					//			echo $v_array[$x]."===".$d5."<br>";
								if ($row5[1] != "")
									{
										$k = $k + $row5[1];
										$n=$n+1;
									}
				}	}
					
				
					
		} }
$result2 = mysql_query("select max(no) from malaylex",$con);
if (!$result2) {
    exit;
}
$row2 = mysql_fetch_row($result2);

//echo('<br />');
$d2=$row2[0];

$d2 = $d2+1;
if ($n != 0)
{
$t= $k/$n;
$p=($k/$n)*($c/29000);
}
echo " = ".$k."<br>";
$sql3 = "INSERT INTO malaylex (no,k,n,cno,p,t,word) VALUES (".$d2.",".$k.",".$n.",".$c.",".$p.",".$t.",'".$d1."')";

if (mysql_query($sql3,$con)) {
  
} else {


}
$p=0.0;
$c=0;
$n=0;
$t=0;
$k = 0;
} }

echo "done";
?>
</body>
</html>