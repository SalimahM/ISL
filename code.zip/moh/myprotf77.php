<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>Untitled Document</title>
</head>

<body>
<p>
  <?php
echo "  The coooooood <br> ";
  ini_set("max_execution_time", 300000000000);
  $o = 0;
  $n=0;
$k = 0;
$t=0;
$num_comm_corpus=258957;
$num_words_in_comm=0;
$num_cand_in_comm=0;
$num_comm=0;
$tfidf=0.0;
$c=0;
$p=0.0;
$num_pos_seed=0;
$num_neg_seed=0;
$d1='';
$con=mysql_connect('localhost','root','asd123456');
if(!$con){
echo "Connection Error";
exit();
}
$db=mysql_select_db('mypro',$con);

mysql_query("set character_set_server='utf8'");
mysql_query("set names 'utf8'");

$sql1=mysql_query("select word from ar_cands772 order by count",$con);
if($sql1){
while($row1=mysql_fetch_array($sql1)){
$d1=$row1[word];
echo "The Candidate Word is: ".$d1;
$sql5=mysql_query("select count(mcomm) from arcomm77 where mcomm like '% ".$d1." %'",$con);
if (!$sql5) {
    exit;
}
$row66 = mysql_fetch_row($sql5);
$num_comm=$row66[0];
echo "num_comm= ".$num_comm."<br>";
	$sql=mysql_query("select mcomm from arcomm77 where mcomm like '% ".$d1." %'",$con);
		if($sql){
				while($row=mysql_fetch_array($sql)){
					$d=$row[mcomm];
					$c=$c+1;
					$v_array = explode(" ", $d);
					$l = count($v_array);
					$num_words_in_comm= $l;
					for ($x = 0; $x <= $l ; $x++) {

						$result = mysql_query("select * from seedlex2 where word ='".$v_array[$x]."'",$con);
							if (!$result) {
								exit;
							}
							else {
								$o = $o +1;
								$row5 = mysql_fetch_row($result);
								$d5=$row5[0];
								if ($row5[1] != "")
									{
										$k = $k + $row5[1];
										$n=$n+1;
										$num_cand_in_comm= $num_cand_in_comm+1;	
										if ($row5[1] == 1)
										 $num_pos_seed = $num_pos_seed +1;
										elseif ($row5[1] == -1)
										 $num_neg_seed = $num_neg_seed -1;
									}	}	}
		echo "num_cand_in_comm = ".$num_cand_in_comm."<br>";
		echo "<br> num_words_in_comm = ".$num_words_in_comm."<br>";
				$tfidf= $tfidf + (($num_cand_in_comm/$num_words_in_comm)*(log10($num_comm_corpus/($num_comm+1))));
				echo "<br> tfidf = ".$tfidf;
				$num_words_in_comm=0;
$num_cand_in_comm=0;
					
				
					
		} }
$result2 = mysql_query("select max(no) from arlex77",$con);
if (!$result2) {
    exit;
}
$row2 = mysql_fetch_row($result2);
$d2=$row2[0];
$d2 = $d2+1;
if ($n != 0)
{
$t= $k/$n;
$p=($k/$n)*($c/258957);
}
echo " = ".$k."<br>";
$sql3 = "INSERT INTO arlex77 (no,k,n,cno,p,t,tfidf,num_pos_s,num_neg_s,word) VALUES(".$d2.",".$k.",".$n.",".$c.",".$p.",".$t.",".$tfidf.",".$num_pos_seed.",".$num_neg_seed.",'".$d1."')";
if (mysql_query($sql3,$con)) {
} else {
echo "No insert";
}
$p=0.0;
$c=0;
$n=0;
$t=0;
$k = 0;
$num_comm =0;
$tfidf= 0.0;
$num_pos_seed=0;
$num_neg_seed=0;
} }

echo "done";
?>
</body>
</html>