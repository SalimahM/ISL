<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>Untitled Document</title>
</head>

<body>
<p>
  <?php
echo "  The coooooood <br> ";
ini_set("max_execution_time", 300000000000);
$o = 0;
$n=0;
$k = 0;
$t=0;
$num_comm_corpus=1416298;
$num_words_in_comm=0;
$num_cand_in_comm=0;
$num_comm=0;
$tfidf=0.0;
$c=0;
$p=0.0;
$num_pos_seed=0;
$num_neg_seed=0;
$d1='';
$con=mysql_connect('localhost','root','asd123456');
if(!$con){
echo "Connection Error";
exit();
}
$db=mysql_select_db('mypro',$con);

mysql_query("set character_set_server='utf8'");
mysql_query("set names 'utf8'");


$sql1=mysql_query("select word from encands1 order by count",$con);
if($sql1){
while($row1=mysql_fetch_array($sql1)){
$d1=$row1[word];
echo "The Candidate Word is: ".$d1;

//count number of comments
$sql5=mysql_query("select count(mcomm) from encomm2 where mcomm like '% ".$d1." %'",$con);

if (!$sql5) {
    exit;
}
$row66 = mysql_fetch_row($sql5);
$num_comm=$row66[0];
echo "num_comm= ".$num_comm."<br>";

	$sql=mysql_query("select mcomm from encomm2 where mcomm like '% ".$d1." %'",$con);
		if($sql){
				while($row=mysql_fetch_array($sql)){
					$d=$row[mcomm];
					$c=$c+1;
				//	echo $d."<br>";
				//	echo "======================== <br>";
					$v_array = explode(" ", $d);
					$l = count($v_array);
					$num_words_in_comm= $l;
					for ($x = 0; $x <= $l ; $x++) {

						$result = mysql_query("select * from enseed where word ='".$v_array[$x]."'",$con);
							if (!$result) {
								exit;
							}
							else {
							//	echo $v_array[$x];
								$o = $o +1;
								//echo "OOOO".$o."<br>";
								$row5 = mysql_fetch_row($result);
								$d5=$row5[0];
							//	echo "D5=  ". $d5. "<br>";
								
					//			echo $v_array[$x]."===".$d5."<br>";
								if ($row5[1] != "")
									{
									//	echo "CORRECT";
										
										$k = $k + $row5[1];
										$n=$n+1;
										$num_cand_in_comm= $num_cand_in_comm+1;	
										if ($row5[1] == 1)
										 $num_pos_seed = $num_pos_seed +1;
										elseif ($row5[1] == -1)
										 $num_neg_seed = $num_neg_seed -1;
									}
				}	}
				
		/*	$a= $num_cand_in_comm/$num_words_in_comm;
			$b= $num_comm_corpus/($num_comm+1);
			$lo = log10($b);
			$tfidf= $tfidf + ($a* $lo);*/
			
		//if (num_cand_in_comm !=0 )
	//	{
		echo " num_cand_in_comm = ".$num_cand_in_comm."<br>";
		echo "<br> num_words_in_comm = ".$num_words_in_comm."<br>";
		
		//echo "<br> num_comm" .$num_comm. "<br>";
		//echo log10($num_comm_corpus/($num_comm+1));*/
				$tfidf= $tfidf + (($num_cand_in_comm/$num_words_in_comm)*(log10($num_comm_corpus/($num_comm+1))));
				echo "<br> tfidf = ".$tfidf;
	//	}
				$num_words_in_comm=0;
$num_cand_in_comm=0;
					
				
					
		} }
$result2 = mysql_query("select max(no) from enlex",$con);
if (!$result2) {
    exit;
}
$row2 = mysql_fetch_row($result2);

//echo('<br />');
$d2=$row2[0];

$d2 = $d2+1;
if ($n != 0)
{
$t= $k/$n;
$p=($k/$n)*($c/$num_comm_corpus);
}


echo " = ".$k."<br>";
$sql3 = "INSERT INTO enlex (no,k,n,cno,p,t,tfidf,num_pos_s,num_neg_s,word) VALUES (".$d2.",".$k.",".$n.",".$c.",".$p.",".$t.",".$tfidf.",".$num_pos_seed.",".$num_neg_seed.",'".$d1."')";

if (mysql_query($sql3,$con)) {
  
} else {
echo "No insert";

}
$p=0.0;
$c=0;
$n=0;
$t=0;
$k = 0;
$num_comm =0;
$tfidf= 0.0;
$num_pos_seed=0;
$num_neg_seed=0;
} }

echo "done";
?>
</body>
</html>