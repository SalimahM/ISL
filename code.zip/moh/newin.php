<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>Untitled Document</title>
</head>

<body>
<p>
  <?php
echo "  The coooooood <br> ";
  ini_set("max_execution_time", 300000000000);
  $n=0;
$k = 0;
$t=0;
$c=0;
$p=0.0;
$d1='';
$con=mysql_connect('localhost','root','asd123456');
if(!$con){
echo "Connection Error";
exit();
}
$db=mysql_select_db('mypro',$con);

mysql_query("set character_set_server='utf8'");
mysql_query("set names 'utf8'");

$sql4 = "INSERT INTO fff (no,mmm) VALUES (3,'ttttt')";

if (mysql_query($sql4,$con)) {
  
} else {
echo "No insert  44";

}

$d2 = 2;
$sql3 = "INSERT INTO frlex (no,k,n,cno,p,t,word) VALUES (".$d2.",".$k.",".$n.",".$c.",".$p.",".$t.",'".$d1."')";

if (mysql_query($sql3,$con)) {
  
} else {
echo "No insert";

}

echo "done";
?>
</body>
</html>