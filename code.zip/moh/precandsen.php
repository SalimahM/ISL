<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>Untitled Document</title>
</head>

<body>
<p>

  <?php
// كود تجهيز قوائم الكلمات المرشحة

  ini_set("max_execution_time", 30000000000);
$n=0;
$k = 0;
$d1='';
$con=mysql_connect('localhost','root','asd123456');
if(!$con){
echo "Connection Error";
exit();
}
$db=mysql_select_db('mypro',$con);

mysql_query("set character_set_server='utf8'");
mysql_query("set names 'utf8'");

$cc = 0;
$sql1=mysql_query("select mcomm from encomm2",$con);
if($sql1){
while($row1=mysql_fetch_array($sql1)){
$d1=$row1[mcomm];
$cc = $cc + 1;
echo $cc." = The Comment is: ".$d1." <br>";

	//$sql=mysql_query("select comment from corr where comment like '% ".$d1." %'",$con);
	//	if($sql){
	//			while($row=mysql_fetch_array($sql)){
					$d=$row1[mcomm];
				//	echo $d."<br>";
				//	echo "======================== <br>";
					$v_array = explode(" ", $d);
					$l = count($v_array);
					for ($x = 0; $x <= $l ; $x++) {

						$result = mysql_query("select * from encands where word ='".$v_array[$x]."'",$con);
							if (!$result) {
								exit;
							}
							else {
								$row5 = mysql_fetch_row($result);
								$d5=$row5[0];
					//			echo $v_array[$x]."===".$d5."<br>";
								if ($row5[0] != "")    // موجودة
									{
										$ttt = $row5[1];
										$ttt = $ttt +1;
										
										
										$sql3 = "update encands set count = ".$ttt." where word ='".$v_array[$x]."'";
										if (mysql_query($sql3,$con)) {
											echo " Update word <br>";
											} else {}
										
									
									}
									else
									{
										$newn = 1;
										$sql4 = "INSERT INTO encands (word,count) VALUES ('".$v_array[$x]."',".$newn.")";
										if (mysql_query($sql4,$con)) {
											echo " Add new word <br>";
											} else {}
										
									}
										
				}	}
					
				
					
		} }

echo "done";
?>
</body>
</html>